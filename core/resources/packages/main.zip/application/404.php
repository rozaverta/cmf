<?php defined("ELS_CMS") || exit;

/**
 * @var \EApp\View\View $view
 */

echo $view->getTpl("main");