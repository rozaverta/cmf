<?php

/**
 * @var \EApp\CI\View $view
 */

echo $view->getTpl("main");