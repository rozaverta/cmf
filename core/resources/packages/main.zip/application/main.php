<?php

/**
 * @var \EApp\CI\View $view
 */

?><!doctype html>
<html lang="<?= $view->get( "language" ) ?>">
<head>
	<meta charset="<?= $view->get( "charset" ) ?>">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title><?= $view->get( "page_title" ) ?></title>
	<style>
		body {
			margin: 0;
			padding: 0;
		}
		.wrap {
			width: 800px;
			margin: 20px auto;
			position: relative;
		}
		.text {
			border-top: 1px solid #ccc;
			padding-top: 20px;
		}
	</style>
</head>
<body>
	<div class="wrap">
		<h1><?= $view->get( "page_title" ) ?></h1>
		<div class="text"><?= $view->get( "content" ) ?></div>
	</div>
</body>
</html>